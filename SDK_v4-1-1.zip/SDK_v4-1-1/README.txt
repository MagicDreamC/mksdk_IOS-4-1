

iOS端线上接入文档地址：https://github.com/MagicDreamC/mksdk_IOS-4-0/blob/master/README.md

服务端线上接入文档地址：https://github.com/MagicDreamC/mksdk_IOS-4-0/blob/master/摩柯游戏平台sdk服务端接入文档%20v2.0.md