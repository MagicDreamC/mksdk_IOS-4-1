//
//  GameScene.h
//  KoalaGameKitDEMO
//
//  Created by kaola  on 2018/5/11.
//  Copyright © 2018年 kaola . All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene

@end
